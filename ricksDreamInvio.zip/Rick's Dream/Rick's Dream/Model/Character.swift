//
//  Character.swift
//  Rick's Dream
//
//  Created by Kaan Uslu on 17.04.2023.
//

import Foundation

struct Character: Identifiable, Codable {
    let id: Int
    let name: String
    let status: String
    let species: String
    let type: String
    let gender: String
    let origin: Origin
    let location: Location
    let image: String
    let episode: [String]
    let url: String
    let created: String
    
    var formattedTime: String {
               let dateFormatter = DateFormatter()
               dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSZ"
               dateFormatter.locale = Locale(identifier: "en_US_POSIX")

               if let date = dateFormatter.date(from: created) {
                   dateFormatter.dateFormat = "d MMM yyyy, HH:mm:ss"
                   return dateFormatter.string(from: date)
               }

               return created
    }
    
    var formattedEpisodes: String {
        let episodeNumbers = episode.map { (url) -> String in
            let components = url.components(separatedBy: "/")
            guard let episodeNumber = components.last else { return "" }
            return episodeNumber
        }

        let formattedEpisodeString = episodeNumbers.joined(separator: ",")
        
        return formattedEpisodeString
    }
    
}
