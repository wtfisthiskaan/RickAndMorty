//
//  Location.swift
//  Rick's Dream
//
//  Created by Kaan Uslu on 19.04.2023.
//

import Foundation

struct Location: Codable{
    let name: String
    let url: String
}
