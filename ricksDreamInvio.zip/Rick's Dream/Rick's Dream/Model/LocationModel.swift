//
//  LocationModel.swift
//  Rick's Dream
//
//  Created by Kaan Uslu on 19.04.2023.
//

import Foundation

struct LocationModel: Codable{
    let id: Int
    let name: String
    let type: String
    let dimension: String
    let residents: [String]
    let url: String
    let created: String
}
