//
//  GifView.swift
//  Rick's Dream
//
//  Created by Kaan Uslu on 20.04.2023.
//

import WebKit
import Foundation
import SwiftUI

struct GifView: UIViewRepresentable {
    
    let gifName: String
    
    func makeUIView(context: UIViewRepresentableContext<GifView>) -> WKWebView {
        return WKWebView()
    }
    
    func updateUIView(_ uiView: WKWebView, context: UIViewRepresentableContext<GifView>){
        if let gifPath = Bundle.main.path(forResource: gifName, ofType: "gif") {
            let url = URL(fileURLWithPath: gifPath)
            uiView.loadFileURL(url, allowingReadAccessTo: url)
            let request = URLRequest(url: url)
            uiView.load(request)
        }
    }
}

