//
//  apiFunctions.swift
//  Rick's Dream
//
//  Created by Kaan Uslu on 19.04.2023.
//

import Foundation

func fetchLocationData(completion: @escaping ([LocationModel]) -> ()){
    let urlString = "https://rickandmortyapi.com/api/location/1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20"
    guard let url = URL(string: urlString) else { return }
    
    let session = URLSession.shared
    let task = session.dataTask(with: url) { data, response, error in
        guard let data = data, error == nil else {
            print("Error: \(error?.localizedDescription ?? "Unknown error")")
            return
        }
        do {
            let decoder = JSONDecoder()
            let result = try decoder.decode([LocationModel].self, from: data)
            completion(result)
        } catch {
            print("Error decoding JSON: \(error.localizedDescription)")
        }
    }
    task.resume()
}



func fetchCharacterData(from url: URL, completion: @escaping (Character?) -> ()) {
    URLSession.shared.dataTask(with: url) { (data, response, error) in
        if let error = error {
            print("Error fetching data: \(error.localizedDescription)")
            completion(nil)
            return
        }

        guard let data = data else {
            print("No data returned from API")
            completion(nil)
            return
        }

        do {
            let decoder = JSONDecoder()
            let dataModel = try decoder.decode(Character.self, from: data)
            completion(dataModel)
        } catch {
            print("Error decoding JSON: \(error.localizedDescription)")
            completion(nil)
        }
    }.resume()
}
