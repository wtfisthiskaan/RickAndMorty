//
//  CharacterDetailView.swift
//  Rick's Dream
//
//  Created by Kaan Uslu on 17.04.2023.
//

import SwiftUI

struct CharacterDetailView: View {
    let character: Character
    let bgColor: Color
    var body: some View {
        ZStack{
            bgColor
            ScrollView() {
                AsyncImage(url: URL(string: character.image)) { image in
                    image
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                    
                } placeholder: {
                }
                .frame(width: 275, height: 275, alignment: .topLeading)
                .padding(.top, 100)
                    .padding(.leading, 20)
                    .padding(.trailing, 20)
                    .padding(.bottom, 50)
                
                VStack(alignment: .leading) {
                    HStack {
                        Text("Status:\t\t")
                            .font(Font.custom("Avenir-Heavy", size: 22))
                        Text(character.status)
                            .font(Font.custom("Avenir-Roman", size: 22))
                    }.padding(.bottom, 5)
                    HStack {
                        Text("Specy:\t\t")
                            .font(Font.custom("Avenir-Heavy", size: 22))
                        Text(character.species)
                            .font(Font.custom("Avenir-Roman", size: 22))
                    }.padding(.bottom, 5)
                    HStack {
                        Text("Gender:\t\t")
                            .font(Font.custom("Avenir-Heavy", size: 22))
                        Text(character.gender)
                            .font(Font.custom("Avenir-Roman", size: 22))
                    }.padding(.bottom, 5)
                    HStack {
                        Text("Origin:\t\t")
                            .font(Font.custom("Avenir-Heavy", size: 22))
                        Text(character.origin.name)
                            .font(Font.custom("Avenir-Roman", size: 22))
                            .minimumScaleFactor(0.01)
                    }.padding(.bottom, 5)
                    HStack {
                        Text("Location:\t")
                            .font(Font.custom("Avenir-Heavy", size: 22))
                        Text(character.location.name)
                            .font(Font.custom("Avenir-Roman", size: 22))
                            .minimumScaleFactor(0.01)
                    }.padding(.bottom, 5)
                    HStack {
                        Text("Episodes:\t")
                            .font(Font.custom("Avenir-Heavy", size: 22))
                        Text(character.formattedEpisodes)
                            .font(Font.custom("Avenir-Roman", size: 22))
                            //.minimumScaleFactor(0.01)
                            .fixedSize(horizontal: false, vertical: true)
                    }.padding(.bottom, 5)
                    HStack {
                        Text("Created at\n(in API):")
                            .fixedSize(horizontal: false, vertical: true)
                            .font(Font.custom("Avenir-Heavy", size: 22))
                        Text(character.formattedTime)
                            .font(Font.custom("Avenir-Roman", size: 21))
                            .minimumScaleFactor(0.01)
                    }.padding(.bottom, 5)
                }
                .background(bgColor)
                .padding(.horizontal, 20)
                
                Spacer()
            }
            .background(bgColor)
            .navigationBarTitle(Text(character.name), displayMode: .inline)
        }
        .ignoresSafeArea()
    }
}


struct CharacterDetailView_Previews: PreviewProvider {
    static var previews: some View {
        
        
        CharacterDetailView(character: Character(id: 1, name: "Beth Smith", status: "Alive", species: "Human", type: "", gender: "Female", origin: Origin(name: "Earth (C-137)", url: "https://rickandmortyapi.com/api/location/1"), location: Location(name: "Earth (C-137)", url: "https://rickandmortyapi.com/api/location/1"), image: "https://rickandmortyapi.com/api/character/avatar/38.jpeg", episode: ["1,2,3"], url: "https://rickandmortyapi.com/api/character/38", created: "2017-11-05T09:48:44.230Z"), bgColor: Color.pink)
        
    }
}
