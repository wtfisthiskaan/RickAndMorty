//
//  CharacterRow.swift
//  Rick's Dream
//
//  Created by Kaan Uslu on 17.04.2023.
//

import Foundation
import SwiftUI


struct CharacterRow: View {
    
    let character: Character
    let bgColor: Color
    var body: some View {
        HStack {
            NavigationLink(destination: CharacterDetailView(character: character,bgColor: bgColor)) {
                Text(character.gender)
                    .font(.custom("GetSchwifty-Regular", size: 22))
                        .textCase(.uppercase)
                        .rotationEffect(Angle(degrees: -90))
                        .fixedSize()
                        .frame(width: 25,height: 100)
                AsyncImage(url: URL(string: character.image)) { image in
                                    image
                                        .resizable()
                                } placeholder: {
                                    Color.gray
                                }
                                .frame(width: 150, height: 150,alignment: .topLeading)
                                .padding(.horizontal, -5)
                                
                Spacer()
                Text(character.name)
                    .font(.custom("GetSchwifty-Regular", size: 22))
                    .padding(.horizontal, 10)
                    .minimumScaleFactor(0.01)
                Spacer()
                
            }
        }
        .navigationBarItems(trailing: Image("logo2")
        .resizable()
        .frame(width:350, height: 60,alignment: .center)
        )
        .onAppear{
            print(character.image)
        }
    }
}
