//
//  ContentView.swift
//  Rick's Dream
//
//  Created by Kaan Uslu on 17.04.2023.
//

import SwiftUI
import CoreData

struct ContentView: View {
    @State var selectedLocationIndex = -1//location index initialized with -1 to change 0
    @State private var locationData = [LocationModel]()
    @State var i = 0// during init, set location one time.
    
    init(){
        //select location index
        
        //change navigation bar appearance to avenir.
        let appearance = UINavigationBarAppearance()
        UILabel.appearance(whenContainedInInstancesOf: [UINavigationBar.self]).adjustsFontSizeToFitWidth = true
        appearance.configureWithDefaultBackground()
        appearance.titleTextAttributes = [.font: UIFont(name: "Avenir-Medium", size: 30)!]

        UINavigationBar.appearance().standardAppearance = appearance
        /*get font name
        for familyName in UIFont.familyNames{
            print(familyName)
            
            for fontName in UIFont.fontNames(forFamilyName: familyName){
                print(fontName,"--")
            }
        }*/
        
    }
    // some color definings..
    let backgroundColor = Color(red: 5 / 255, green: 20 / 255, blue: 24 / 255)
    
    let selectedItemColor = Color(red: 80 / 255, green: 177 / 255, blue: 209 / 255)
    
    let unSelectedItemColor = Color(red: 151 / 255, green: 206 / 255, blue: 76 / 255)
    
    let womanColor = Color(red: 232 / 255, green: 154 / 255, blue: 199 / 255)
    
    let manColor = Color(red: 1 / 255, green: 180 / 255, blue: 198 / 255) //#01b4c6
    
    let genderlessColor = Color(red: 240 / 255, green: 225 / 255, blue: 74 / 255)
    
    
    @State var currentCharacters = [Character]()
    
    var body: some View {
        NavigationView{
            VStack {
                ScrollView(.horizontal, showsIndicators: false){
                    HStack(spacing: 0) {
                        ForEach(locationData.indices, id: \.self){ index in
                            Button(action: {
                                selectedLocationIndex = index
                            }) {
                                Text(self.locationData[index].name)
                                    .foregroundColor(.white)
                                    .font(Font.custom("Avenir", size: 22))
                                    .frame(width: 200, height: 50)
                                    .background(selectedLocationIndex == index ? selectedItemColor : unSelectedItemColor)
                                    .cornerRadius(25)
                                    .fixedSize(horizontal: true, vertical: false)
                                    .padding(.horizontal, 8)
                                    .padding(.vertical, 8)
                                    .minimumScaleFactor(0.01)
                            }
                        }
                        Spacer()
                    }
                }.onAppear {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1){
                        if(i==0){
                            selectedLocationIndex = 0
                            i += 1
                        }
                        fetchLocationData { locationData in
                            self.locationData = locationData
                        }
                    }
                }
                if currentCharacters.count == 0{
                    GifView(gifName: "emptyGif")
                                .frame(width: 300, height: 169)
                                .padding(.top,150)
                                .navigationBarItems(trailing: Image("logo2")
                                .resizable()
                                .frame(width:350, height: 60,alignment: .center)
                                )
                }
                List(currentCharacters) { character in
                    CharacterRow(character: character,bgColor: character.gender == "Male" ? manColor : character.gender == "Female" ? womanColor : genderlessColor)
                        .frame(width: 350,height: 150)
                        .listRowBackground(backgroundColor)
                        .background(character.gender == "Male" ? manColor : character.gender == "Female" ? womanColor : genderlessColor)
                        .cornerRadius(25)
                }
                .background(backgroundColor)
                .scrollContentBackground(.hidden)
                .onChange(of: selectedLocationIndex) { _ in
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.11) {
                        if(selectedLocationIndex < locationData.count){
                            currentCharacters = []
                            let group = DispatchGroup()
                            for url in self.locationData[selectedLocationIndex].residents {
                                group.enter()
                                let apiUrl = URL(string: url)!
                                fetchCharacterData(from: apiUrl) { dataModel in
                                    DispatchQueue.main.async {
                                        if let fetchedCharacter = dataModel {
                                            currentCharacters.append(fetchedCharacter)
                                        }
                                        group.leave()
                                    }
                                }
                            }
                            group.notify(queue: .main) {
                                print("All characters fetched")
                            }
                        }
                    }
                }
            }
            .background(backgroundColor)
            
        }.accentColor(.black)
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView().environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
    }
}

