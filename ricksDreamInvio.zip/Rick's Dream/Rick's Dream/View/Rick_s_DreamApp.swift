//
//  Rick_s_DreamApp.swift
//  Rick's Dream
//
//  Created by Kaan Uslu on 17.04.2023.
//

import SwiftUI

@main
struct Rick_s_DreamApp: App {
    let persistenceController = PersistenceController.shared
    
    var body: some Scene {
        WindowGroup {
            SplashScreen()
            //ContentView()
              //  .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
    
}

