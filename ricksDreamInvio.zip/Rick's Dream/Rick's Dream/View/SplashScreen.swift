//
//  SplashScreen.swift
//  Rick's Dream
//
//  Created by Kaan Uslu on 20.04.2023.
//

import SwiftUI

struct SplashScreen: View {
    @State var isActive = false
    var body: some View {
        if isActive{
            ContentView()
        }
        else{
            ZStack{
                Color(red: 33 / 255, green: 33 / 255, blue: 33 / 255).ignoresSafeArea()
                GifView(gifName: "splashGif")
                    .frame(width: 500,height: 500)
                    .padding()
                
                if !UserDefaults.standard.bool(forKey: "launchedBefore") {
                    Text("Welcome")
                        .font(.custom("GetSchwifty-Regular", size: 50))
                        .padding(.bottom, 300)
                        .onAppear {
                            UserDefaults.standard.set(true, forKey: "launchedBefore")
                        }
                } else {
                    Text("Hello")
                        .font(.custom("GetSchwifty-Regular", size: 50))
                        .padding(.bottom, 300)
                }
                
            }.onAppear {
                DispatchQueue.main.asyncAfter(deadline: .now() + 2.5){
                    isActive = true
                }
            }
        }
        
    }
}


struct SplashScreen_Previews: PreviewProvider {
    static var previews: some View {
        SplashScreen()
    }
}
